export default (props) => {
    return (
        <div className="rishi-ad_icon-link-group">{props.children}</div>
    )
}